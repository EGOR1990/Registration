<template>
    <h1>
        Мне 16лет. Меня зовут Егор
    </h1>
<UserForm>
</UserForm>
    <RouterLink to="/">На главную</RouterLink>

</template>
<script lang="ts">
import { defineComponent } from 'vue';
import {RouterLink} from "vue-router";
import UserForm from '@/components/UserForm.vue';
export default defineComponent(
    {
        name:"About",
        components: {UserForm}
       
            },
        
);
</script>