<template>
    <div class="button" style="width: 600px;height: 250px;">
        <h1> Форма обратной связи</h1>
        <form @submit.prevent="submitForm">
            <div>
                <label for="name">Имя: </label>
                <input type="text" v-model="user.name" required />
            </div>
            <div>
                <label for="email">Электронная почта: </label>
                <input type="email" v-model="user.email" required />
            </div>
            <div>
                <label for="age">Возраст: </label>
                <input type="number" v-model="user.age" required  />
            </div>
            <div>
                <label for="numphone">Номер телефона: </label>
                <input type="text" v-model="user.numphone" required  />
            </div>
<!--required обязательно заполнить ячейку -->
            <button class="button" type="submit">Потвердить</button>
        </form>
        <div v-if="submitted">
            <h2>Полученная информация: </h2>
            <p>Имя: {{ user.name }}</p>
            <p>Эл.почта: {{ user.email }}</p>
            <p>Возраст: {{ user.age }}</p>
            <p>Номер телефона: {{ user.numphone }}</p>

        </div>
    </div>
    
</template>
<script lang="ts">
import UserForm from './components/UserForm.css';
import {defineComponent, ref } from 'vue';
export default defineComponent(
    {

        name: "UserForm",
        setup() 
        {
            const user = ref 
    ({
                name: '',
                email: '',
                age: null as number | null,
                numphone: null as number | null
            });
            const submitted = ref(false)
            const submitForm = () => {
                submitted.value = true;
            };
            return{
                user,
                submitted,
                submitForm,
            };
        },
    }
);
</script>
<style>
.button{
    color:rgb(10, 66, 99);
    font-size: 20px;
    background-color: rgb(170, 197, 218);
    border-radius: 5px;
    align-items: center;
    text-align: center;


}
</style>